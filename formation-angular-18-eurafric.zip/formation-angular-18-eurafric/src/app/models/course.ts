export interface Course {
    id?: number;
    title: string;
    image: string;
    price: number;
    body: string;
    active: boolean;
}
