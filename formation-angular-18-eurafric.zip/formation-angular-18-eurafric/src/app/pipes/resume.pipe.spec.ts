import { ResumePipe } from './resume.pipe';

describe('ResumePipe', () => {
  it('create an instance', () => {
    const pipe = new ResumePipe();
    expect(pipe).toBeTruthy();
  });
});
