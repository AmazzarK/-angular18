import { CounterState } from "./counter.model";

export const initCounterState: CounterState  = {

    count: 12
} 