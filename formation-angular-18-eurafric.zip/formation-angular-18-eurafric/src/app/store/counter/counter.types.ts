export const COUNTER_INCEREMENT = '[Counter] increment count'
export const COUNTER_DECEREMENT = '[Counter] decrement count'
export const COUNTER_RESET = '[Counter] reset count'